package com.greatfree.server;

import com.greatfree.concurrency.MessageProducer;
import com.greatfree.concurrency.Runner;
import com.greatfree.message.ServerMessage;
import com.greatfree.remote.OutMessageStream;

/*
 * This is an instantiating-enabled ServerMessageProducer. For application developers, they just need to work on it. 04/16/2017, Bing Li
 */

// Created: 04/16/2017, Bing Li
public class ServerMessageProducer<Dispatcher extends ServerDispatcher>
{
	// The Threader aims to associate with the message producer to guarantee the producer can work concurrently. 09/20/2014, Bing Li
	private Runner<MessageProducer<Dispatcher>, ServerProducerDisposer<Dispatcher>> producerThreader;

	/*
	 * Dispose the producers when the process of the server is shutdown. 08/22/2014, Bing Li
	 */
	public void dispose() throws InterruptedException
	{
		this.producerThreader.stop();
	}
	
	/*
	 * Initialize the message producers. It is invoked when the connection modules of the server is started since clients can send requests or notifications only after it is started. 08/22/2014, Bing Li
	 */
	public void init(Dispatcher dispatcher)
	{
		// Initialize the message producer. A threader is associated with the message producer such that the producer is able to work in a concurrent way. 09/20/2014, Bing Li
		this.producerThreader = new Runner<MessageProducer<Dispatcher>, ServerProducerDisposer<Dispatcher>>(new MessageProducer<Dispatcher>(dispatcher), new ServerProducerDisposer<Dispatcher>());
		// Start the associated thread for the message producer. 09/20/2014, Bing Li
		this.producerThreader.start();
	}
	
	/*
	 * Assign messages, requests or notifications, to the bound message dispatcher such that they can be responded or dealt with. 09/20/2014, Bing Li
	 */
	public void produceMessage(OutMessageStream<ServerMessage> message)
	{
		this.producerThreader.getFunction().produce(message);
	}
}
