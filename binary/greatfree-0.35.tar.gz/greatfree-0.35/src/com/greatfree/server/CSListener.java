package com.greatfree.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import com.greatfree.concurrency.ThreadPool;
import com.greatfree.remote.ServerIORegistry;
import com.greatfree.remote.ServerListener;
import com.greatfree.testing.data.Prompts;
import com.greatfree.testing.data.ServerConfig;
import com.greatfree.util.ServerStatus;

// Created: 04/20/2017, Bing Li
public class CSListener<Dispatcher extends ServerDispatcher> extends ServerListener implements Runnable
{
//	private final int port;
	// Declare the server message producer, which is the important part of the server. Application developers can work on that directly through programming Dispatcher. 04/17/2017, Bing Li
	private ServerMessageProducer<Dispatcher> messageProducer;
	// The registry keeps all of the server IOs' instances. 04/19/2017, Bing Li
	private ServerIORegistry<CSServerIO<Dispatcher>> ioRegistry;

	public CSListener(ServerSocket serverSocket, ThreadPool pool, ServerMessageProducer<Dispatcher> messageProducer, ServerIORegistry<CSServerIO<Dispatcher>> ioRegistry)
	{
		super(serverSocket, pool);
		this.messageProducer = messageProducer;
		this.ioRegistry = ioRegistry;
	}

	/*
	 * The task that must be executed concurrently. 08/22/2014, Bing Li
	 */
	@Override
	public void run()
	{
		Socket clientSocket;
		CSServerIO<Dispatcher> serverIO;

		// Detect whether the listener is shutdown. If not, it must be running all the time to wait for potential connections from clients. 08/22/2014, Bing Li
		while (!this.isShutdown())
		{
			// Wait and accept a connecting from a possible client. 08/22/2014, Bing Li
			try
			{
				// Wait and accept a connecting from a possible client. 08/22/2014, Bing Li
				clientSocket = super.accept();
				// Check whether the connected server IOs exceed the upper limit. 08/22/2014, Bing Li
				if (this.ioRegistry.getIOCount() >= ServerConfig.MAX_SERVER_IO_COUNT)
				{
					// If the upper limit is reached, the listener has to wait until an existing server IO is disposed. 08/22/2014, Bing Li
					super.holdOn();
				}

				// If the upper limit of IOs is not reached, a server IO is initialized. A common Collaborator and the socket are the initial parameters. The shared common collaborator guarantees all of the server IOs from a certain client could notify with each other with the same lock. Then, the upper limit of server IOs is under the control. 08/22/2014, Bing Li
//				serverIO = new DispatchingServerIO<Dispatcher>(clientSocket, super.getCollaborator(), this.port, this.messageProducer, this.ioRegistry);
				serverIO = new CSServerIO<Dispatcher>(clientSocket, super.getCollaborator(), this.messageProducer, this.ioRegistry);

				// Add the new created server IO into the registry for further management. 08/22/2014, Bing Li
				this.ioRegistry.addIO(serverIO);
				// Execute the new created server IO concurrently to respond the client requests and notifications in an asynchronous manner. 08/22/2014, Bing Li
				super.execute(serverIO);
			}
			catch (IOException | InterruptedException e)
			{
				ServerStatus.FREE().printException(Prompts.SOCKET_GOT_EXCEPTION);
			}
			
		}
		
		
	}

}
