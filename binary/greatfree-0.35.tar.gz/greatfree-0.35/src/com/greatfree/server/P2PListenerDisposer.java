package com.greatfree.server;

import com.greatfree.reuse.RunDisposable;

/*
 * The class is responsible for disposing the instance of dispatching server istener by invoking its method of shutdown(). 09/20/2014, Bing Li
 */

// Created: 04/19/2017, Bing Li
public class P2PListenerDisposer<Dispatcher extends ServerDispatcher> implements RunDisposable<P2PListener<Dispatcher>>
{

	@Override
	public void dispose(P2PListener<Dispatcher> r) throws InterruptedException
	{
		r.shutdown();
	}

	@Override
	public void dispose(P2PListener<Dispatcher> r, long time) throws InterruptedException
	{
		r.shutdown();
	}

}
