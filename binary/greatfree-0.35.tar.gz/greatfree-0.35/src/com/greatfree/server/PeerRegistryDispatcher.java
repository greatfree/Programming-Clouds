package com.greatfree.server;

import java.util.Calendar;

import com.greatfree.chat.registry.ClusterIPRequestThread;
import com.greatfree.chat.registry.ClusterIPRequestThreadCreator;
import com.greatfree.concurrency.RequestDispatcher;
import com.greatfree.message.ClusterIPRequest;
import com.greatfree.message.ClusterIPResponse;
import com.greatfree.message.ClusterIPStream;
import com.greatfree.message.PortRequest;
import com.greatfree.message.PortResponse;
import com.greatfree.message.PortStream;
import com.greatfree.message.RegisterPeerRequest;
import com.greatfree.message.RegisterPeerResponse;
import com.greatfree.message.RegisterPeerStream;
import com.greatfree.message.ServerMessage;
import com.greatfree.message.SystemMessageType;
import com.greatfree.message.UnregisterPeerRequest;
import com.greatfree.message.UnregisterPeerResponse;
import com.greatfree.message.UnregisterPeerStream;
import com.greatfree.remote.OutMessageStream;
import com.greatfree.testing.data.ServerConfig;

/*
 * 1) Since a peer probably conflicts with others' ports, the registry server needs to assign idle ports to those peers.
 * 
 * 2) Before each peer interacts with each other, they needs to get their IP address from the registry server.
 * 
 * 05/01/2017, Bing Li
 * 
 */

// Created: 05/01/2017, Bing Li
public class PeerRegistryDispatcher extends ServerDispatcher
{
	// Declare a request dispatcher to respond peers' registering requests concurrently. 05/01/2017, Bing Li
	private RequestDispatcher<RegisterPeerRequest, RegisterPeerStream, RegisterPeerResponse, RegisterPeerThread, RegisterPeerThreadCreator> registerPeerRequestDispatcher;

	// Declare a request dispatcher to respond a peer's idle port request concurrently. 05/02/2017, Bing Li
	private RequestDispatcher<PortRequest, PortStream, PortResponse, PortRequestThread, PortRequestThreadCreator> portRequestDispatcher;

	// Declare a request dispatcher to respond IP addresses of the cluster requests concurrently. 04/17/2017, Bing Li
	private RequestDispatcher<ClusterIPRequest, ClusterIPStream, ClusterIPResponse, ClusterIPRequestThread, ClusterIPRequestThreadCreator> clusterIPRequestDispatcher;

	// Declare a request dispatcher to respond peers' unregistering requests concurrently. 05/01/2017, Bing Li
	private RequestDispatcher<UnregisterPeerRequest, UnregisterPeerStream, UnregisterPeerResponse, UnregisterPeerThread, UnregisterPeerThreadCreator> unregisterPeerRequestDispatcher;

	/*
	 * The constructor of PeerRegistryDispatcher. 05/01/2017, Bing Li
	 */
	public PeerRegistryDispatcher(int threadPoolSize, long threadKeepAliveTime, int schedulerPoolSize, long schedulerKeepAliveTime)
	{
		super(threadPoolSize, threadKeepAliveTime, schedulerPoolSize, schedulerKeepAliveTime);

		this.registerPeerRequestDispatcher = new RequestDispatcher.RequestDispatcherBuilder<RegisterPeerRequest, RegisterPeerStream, RegisterPeerResponse, RegisterPeerThread, RegisterPeerThreadCreator>()
				.poolSize(ServerConfig.REQUEST_DISPATCHER_POOL_SIZE)
				.keepAliveTime(ServerConfig.REQUEST_DISPATCHER_THREAD_ALIVE_TIME)
				.threadCreator(new RegisterPeerThreadCreator())
				.maxTaskSize(ServerConfig.MAX_REQUEST_TASK_SIZE)
				.dispatcherWaitTime(ServerConfig.REQUEST_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.REQUEST_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_PERIOD)
				.scheduler(super.getSchedulerPool())
				.build();

		this.portRequestDispatcher = new RequestDispatcher.RequestDispatcherBuilder<PortRequest, PortStream, PortResponse, PortRequestThread, PortRequestThreadCreator>()
				.poolSize(ServerConfig.REQUEST_DISPATCHER_POOL_SIZE)
				.keepAliveTime(ServerConfig.REQUEST_DISPATCHER_THREAD_ALIVE_TIME)
				.threadCreator(new PortRequestThreadCreator())
				.maxTaskSize(ServerConfig.MAX_REQUEST_TASK_SIZE)
				.dispatcherWaitTime(ServerConfig.REQUEST_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.REQUEST_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_PERIOD)
				.scheduler(super.getSchedulerPool())
				.build();

		this.clusterIPRequestDispatcher = new RequestDispatcher.RequestDispatcherBuilder<ClusterIPRequest, ClusterIPStream, ClusterIPResponse, ClusterIPRequestThread, ClusterIPRequestThreadCreator>()
				.poolSize(ServerConfig.REQUEST_DISPATCHER_POOL_SIZE)
				.keepAliveTime(ServerConfig.REQUEST_DISPATCHER_THREAD_ALIVE_TIME)
				.threadCreator(new ClusterIPRequestThreadCreator())
				.maxTaskSize(ServerConfig.MAX_REQUEST_TASK_SIZE)
				.dispatcherWaitTime(ServerConfig.REQUEST_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.REQUEST_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_PERIOD)
				.scheduler(super.getSchedulerPool())
				.build();

		this.unregisterPeerRequestDispatcher = new RequestDispatcher.RequestDispatcherBuilder<UnregisterPeerRequest, UnregisterPeerStream, UnregisterPeerResponse, UnregisterPeerThread, UnregisterPeerThreadCreator>()
				.poolSize(ServerConfig.REQUEST_DISPATCHER_POOL_SIZE)
				.keepAliveTime(ServerConfig.REQUEST_DISPATCHER_THREAD_ALIVE_TIME)
				.threadCreator(new UnregisterPeerThreadCreator())
				.maxTaskSize(ServerConfig.MAX_REQUEST_TASK_SIZE)
				.dispatcherWaitTime(ServerConfig.REQUEST_DISPATCHER_WAIT_TIME)
				.waitRound(ServerConfig.REQUEST_DISPATCHER_WAIT_ROUND)
				.idleCheckDelay(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_DELAY)
				.idleCheckPeriod(ServerConfig.REQUEST_DISPATCHER_IDLE_CHECK_PERIOD)
				.scheduler(super.getSchedulerPool())
				.build();
	}

	/*
	 * Shut down the server message dispatcher. 04/15/2017, Bing Li
	 */
	public void shutdown() throws InterruptedException
	{
		this.registerPeerRequestDispatcher.dispose();
		this.portRequestDispatcher.dispose();
		this.clusterIPRequestDispatcher.dispose();
		this.unregisterPeerRequestDispatcher.dispose();
		super.shutdown();
	}

	/*
	 * Process the available messages in a concurrent way. 04/17/2017, Bing Li
	 */
	public void consume(OutMessageStream<ServerMessage> message)
	{
		// Check the types of received messages. 04/17/2017, Bing Li
		switch (message.getMessage().getType())
		{
			case SystemMessageType.REGISTER_PEER_REQUEST:
				System.out.println("REGISTER_PEER_REQUEST received @" + Calendar.getInstance().getTime());
				// Check whether the registry dispatcher is ready. 04/17/2017, Bing Li
				if (!this.registerPeerRequestDispatcher.isReady())
				{
					// Execute the registry dispatcher as a thread. 04/17/2017, Bing Li
					super.execute(this.registerPeerRequestDispatcher);
				}
				// Enqueue the request into the dispatcher for concurrent responding. 04/17/2017, Bing Li
				this.registerPeerRequestDispatcher.enqueue(new RegisterPeerStream(message.getOutStream(), message.getLock(), (RegisterPeerRequest) message.getMessage()));
				break;

			case SystemMessageType.PORT_REQUEST:
				System.out.println("PORT_REQUEST received @" + Calendar.getInstance().getTime());
				// Check whether the port request dispatcher is ready. 04/17/2017, Bing Li
				if (!this.portRequestDispatcher.isReady())
				{
					// Execute the registry dispatcher as a thread. 04/17/2017, Bing Li
					super.execute(this.portRequestDispatcher);
				}
				// Enqueue the request into the dispatcher for concurrent responding. 04/17/2017, Bing Li
				this.portRequestDispatcher.enqueue(new PortStream(message.getOutStream(), message.getLock(), (PortRequest) message.getMessage()));
				break;

			case SystemMessageType.CLUSTER_IP_REQUEST:
				System.out.println("CLUSTER_IP_REQUEST received @" + Calendar.getInstance().getTime());
				// Check whether the port request dispatcher is ready. 04/17/2017, Bing Li
				if (!this.clusterIPRequestDispatcher.isReady())
				{
					// Execute the registry dispatcher as a thread. 04/17/2017, Bing Li
					super.execute(this.clusterIPRequestDispatcher);
				}
				// Enqueue the request into the dispatcher for concurrent responding. 04/17/2017, Bing Li
				this.clusterIPRequestDispatcher.enqueue(new ClusterIPStream(message.getOutStream(), message.getLock(), (ClusterIPRequest) message.getMessage()));
				break;
				
			case SystemMessageType.UNREGISTER_PEER_REQUEST:
				System.out.println("UNREGISTER_PEER_REQUEST received @" + Calendar.getInstance().getTime());
				// Check whether the port request dispatcher is ready. 04/17/2017, Bing Li
				if (!this.unregisterPeerRequestDispatcher.isReady())
				{
					// Execute the registry dispatcher as a thread. 04/17/2017, Bing Li
					super.execute(this.unregisterPeerRequestDispatcher);
				}
				// Enqueue the request into the dispatcher for concurrent responding. 04/17/2017, Bing Li
				this.unregisterPeerRequestDispatcher.enqueue(new UnregisterPeerStream(message.getOutStream(), message.getLock(), (UnregisterPeerRequest) message.getMessage()));
				break;
		}
	}
}
