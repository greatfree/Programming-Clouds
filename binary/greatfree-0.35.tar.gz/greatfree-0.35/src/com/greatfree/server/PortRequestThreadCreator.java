package com.greatfree.server;

import com.greatfree.concurrency.RequestThreadCreatable;
import com.greatfree.message.PortRequest;
import com.greatfree.message.PortResponse;
import com.greatfree.message.PortStream;

// Created: 05/02/2017, Bing Li
public class PortRequestThreadCreator implements RequestThreadCreatable<PortRequest, PortStream, PortResponse, PortRequestThread>
{

	@Override
	public PortRequestThread createRequestThreadInstance(int taskSize)
	{
		return new PortRequestThread(taskSize);
	}

}
