package com.greatfree.server;

import com.greatfree.concurrency.MessageProducer;
import com.greatfree.reuse.RunDisposable;

/*
 * The disposer is designed for ServerMessageProducerInstance rather than ServerMessageProducer. 04/16/2017, Bing Li
 */

// Created: 04/16/2017, Bing Li
public class ServerProducerDisposer<Dispatcher extends ServerDispatcher> implements  RunDisposable<MessageProducer<Dispatcher>>
{

	@Override
	public void dispose(MessageProducer<Dispatcher> r) throws InterruptedException
	{
		r.dispose();
	}

	@Override
	public void dispose(MessageProducer<Dispatcher> r, long time) throws InterruptedException
	{
		r.dispose();
	}

}
