package com.greatfree.server;

import com.greatfree.reuse.RunDisposable;

// Created: 04/20/2017, Bing Li
public class CSListenerDisposer<Dispatcher extends ServerDispatcher> implements RunDisposable<CSListener<Dispatcher>>
{

	@Override
	public void dispose(CSListener<Dispatcher> r) throws InterruptedException
	{
		r.shutdown();
	}

	@Override
	public void dispose(CSListener<Dispatcher> r, long time) throws InterruptedException
	{
		r.shutdown();
	}

}
