package com.greatfree.util;

// Created: 
public class Prompts
{
	public final static String THREAD_POOL_EXECUTION_REJECTED = "ThreadPool execution rejected!";
}
