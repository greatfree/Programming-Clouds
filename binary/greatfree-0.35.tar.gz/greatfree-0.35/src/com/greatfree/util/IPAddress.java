package com.greatfree.util;

import java.io.Serializable;

/*
 * The IP address information is enclosed in the class. It is usually transmitted from the registry server to a cluster root. So, it must implement the interface of Serializable. 05/08/2017, Bing Li
 */

// Created: 05/08/2017, Bing Li
public class IPAddress implements Serializable
{
	private static final long serialVersionUID = -3975747063145993736L;
	
	private String key;
	private String ip;
	private int port;
	
	public IPAddress(String key, String ip, int port)
	{
		this.key = key;
		this.ip = ip;
		this.port = port;
	}
	
	public String getKey()
	{
		return this.key;
	}
	
	public String getIP()
	{
		return this.ip;
	}
	
	public int getPort()
	{
		return this.port;
	}
}
