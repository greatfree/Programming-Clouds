package com.greatfree.util;

// Created: 12/06/2015, Bing Li
//public abstract class Pointing implements Serializable
public abstract class Pointing extends SerializedKey
{
	private static final long serialVersionUID = -5549376092897969493L;
	//	private int index;
	private double points;
//	private int maxIndex;
	
//	public Pointing(int index, double points, int maxIndex)
//	public Pointing(int index, double points)
	public Pointing(String key, double points)
	{
		super(key);
//		this.index = index;
		this.points = points;
//		this.maxIndex = maxIndex;
	}

	/*
	public Pointing(double points)
	{
		this.points = points;
		this.index = SocialRanks.NO_INDEX;
	}
	
	public int getIndex()
	{
		return this.index;
	}
	
	public void setIndex(int index)
	{
		this.index = index;
	}
	*/
	
	public double getPoints()
	{
		return this.points;
	}
	
	public void setPoints(double points)
	{
		this.points = points;
	}

	/*
	public int getMaxIndex()
	{
		return this.maxIndex;
	}
	*/
}
