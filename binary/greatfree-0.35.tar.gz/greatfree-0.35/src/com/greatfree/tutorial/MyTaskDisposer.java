package com.greatfree.tutorial;

import com.greatfree.reuse.RunDisposable;

// Created: 05/10/2015, Bing Li
public class MyTaskDisposer implements RunDisposable<MyTask>
{
	@Override
	public void dispose(MyTask t)
	{
		t.dispose();
	}

	@Override
	public void dispose(MyTask t, long time)
	{
		t.dispose();
	}
}
