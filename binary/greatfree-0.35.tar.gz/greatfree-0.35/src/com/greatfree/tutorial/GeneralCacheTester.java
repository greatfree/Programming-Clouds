package com.greatfree.tutorial;

import java.util.Map;

import com.greatfree.cache.PersistableMap;
import com.greatfree.util.Tools;

// Created: 03/27/2016, Bing Li
public class GeneralCacheTester
{

	public static void main(String[] args)
	{
//		GeneralCache<String, String> cache = new GeneralCache<String, String>("General", "/home/libing/Temp/GeneralCache.xml");
//		PersistableCache<String, String> cache = new PersistableCache<String, String>("/home/libing/Temp/GeneralCache.xml");
//		PersistableMap<String, String> cache = new PersistableMap<String, String>("D:\\Temp\\GeneralCache.xml");
		PersistableMap<String, String> cache = new PersistableMap<String, String>("/Temp/GeneralCache.xml");
		/*
		cache.put("001", "Li Bing");
		cache.put("002", "Maomao");
		cache.put("003", "River");
		cache.put("004", "Sea");
		cache.put("005", "Platu");

		System.out.println("===============================");

		System.out.println(cache.get("001"));
		System.out.println(cache.get("002"));
		System.out.println(cache.get("003"));
		System.out.println(cache.get("004"));
		System.out.println(cache.get("005"));
		*/

		System.out.println("===============================");

		/*
		Set<Object> keys = cache.getMemKeys();
		Set<String> allKeys = Sets.newHashSet();
		for (Object key : keys)
		{
			System.out.println("key (mem) = " + (String)key);
			allKeys.add((String)key);
		}
		*/

		System.out.println("===============================");

		/*
		keys = cache.getKeys();
		for (Object key : keys)
		{
			System.out.println("key = " + (String)key);
		}
		*/

		System.out.println("===============================");

		/*
		Map<String, ICacheElement<String, String>>  values = cache.get(allKeys);
		for (ICacheElement<String, String> v : values.values())
		{
			System.out.println(v.getKey() + ", " + v.getVal());
		}
		*/
		
		System.out.println("===============================");
		
		/*
		Map<String, String> newValues = cache.get(allKeys);
		for (Map.Entry<String, String> v : newValues.entrySet())
		{
			System.out.println(v.getKey() + ", " + v.getValue());
		}
		*/

		System.out.println("===============================");
		
		Map<String, String> latestValues = cache.getValues();
		for (Map.Entry<String, String> v : latestValues.entrySet())
		{
			System.out.println(v.getKey() + ", " + v.getValue());
		}

		System.out.println("===============================");
		
		for (int i = 1; i < 500; i++)
		{
			cache.put("00" + i, Tools.generateUniqueKey());
			
		}

		cache.dispose();
	}

}
