package com.greatfree.testing.server;

import java.io.IOException;
import java.util.Scanner;

import com.greatfree.chat.ChatConfig;
import com.greatfree.chat.message.cs.AddPartnerNotification;
import com.greatfree.chat.message.cs.PollNewSessionsRequest;
import com.greatfree.chat.message.cs.PollNewSessionsResponse;
import com.greatfree.exceptions.RemoteReadException;
import com.greatfree.server.Peer;
import com.greatfree.chat.server.ChatServerDispatcher;
import com.greatfree.testing.data.ClientConfig;
import com.greatfree.testing.data.ServerConfig;
import com.greatfree.util.NodeID;
import com.greatfree.util.TerminateSignal;

// Created: 05/01/2017, Bing Li
public class StartPeer
{

	public static void main(String[] args) throws IOException, ClassNotFoundException, RemoteReadException, InterruptedException
	{
		// Initialize a command input console for users to interact with the system. 09/21/2014, Bing Li
		Scanner in = new Scanner(System.in);

		System.out.println("Chatting peer starting up ...");

//		Peer<ChatServerDispatcher> peer = new Peer<ChatServerDispatcher>("", ChatConfig.CHAT_SERVER_PORT, ServerConfig.LISTENING_THREAD_COUNT, SharedThreadPool.SHARED().getPool(), new ChatServerDispatcher(ChatConfig.DISPATCHER_POOL_SIZE, ChatConfig.DISPATCHER_POOL_THREAD_POOL_ALIVE_TIME), ChatConfig.CLIENT_POOL_SIZE, ClientConfig.SERVER_CLIENT_POOL_SIZE, ChatConfig.CLIENT_IDLE_CHECK_DELAY, ChatConfig.CLIENT_IDLE_CHECK_PERIOD, ChatConfig.CLIENT_MAX_IDLE_TIME, ClientConfig.ASYNC_EVENT_QUEUE_SIZE, ClientConfig.ASYNC_EVENTER_SIZE, ClientConfig.ASYNC_EVENTING_WAIT_TIME, ClientConfig.ASYNC_EVENTER_WAIT_TIME, ClientConfig.ASYNC_EVENTER_WAIT_ROUND, ClientConfig.ASYNC_EVENT_IDLE_CHECK_DELAY, ClientConfig.ASYNC_EVENT_IDLE_CHECK_PERIOD, ClientConfig.EVENTER_THREAD_POOL_SIZE, ClientConfig.EVENTER_THREAD_POOL_ALIVE_TIME, ServerConfig.SCHEDULER_POOL_SIZE, ServerConfig.SCHEDULER_KEEP_ALIVE_TIME);
		Peer<ChatServerDispatcher> peer = new Peer<ChatServerDispatcher>("", ChatConfig.CHAT_SERVER_PORT, ServerConfig.LISTENING_THREAD_COUNT, ServerConfig.SHARED_THREAD_POOL_SIZE, ServerConfig.SHARED_THREAD_POOL_KEEP_ALIVE_TIME, new ChatServerDispatcher(ChatConfig.DISPATCHER_THREAD_POOL_SIZE, ChatConfig.DISPATCHER_THREAD_POOL_KEEP_ALIVE_TIME, ServerConfig.SCHEDULER_POOL_SIZE, ServerConfig.SCHEDULER_KEEP_ALIVE_TIME), ChatConfig.CLIENT_POOL_SIZE, ClientConfig.CLIENT_READER_POOL_SIZE, ChatConfig.CLIENT_IDLE_CHECK_DELAY, ChatConfig.CLIENT_IDLE_CHECK_PERIOD, ChatConfig.CLIENT_MAX_IDLE_TIME, ClientConfig.ASYNC_EVENT_QUEUE_SIZE, ClientConfig.ASYNC_EVENTER_SIZE, ClientConfig.ASYNC_EVENTING_WAIT_TIME, ClientConfig.ASYNC_EVENTER_WAIT_TIME, ClientConfig.ASYNC_EVENTER_WAIT_ROUND, ClientConfig.ASYNC_EVENT_IDLE_CHECK_DELAY, ClientConfig.ASYNC_EVENT_IDLE_CHECK_PERIOD, ClientConfig.EVENTER_THREAD_POOL_SIZE, ClientConfig.EVENTER_THREAD_POOL_ALIVE_TIME, ClientConfig.SCHEDULER_POOL_SIZE, ClientConfig.SCHEDULER_KEEP_ALIVE_TIME);
		
		peer.start();
		
		System.out.println("Chatting peer started ...");

		peer.syncNotify(ChatConfig.CHAT_SERVER_ADDRESS, ChatConfig.CHAT_SERVER_PORT, new AddPartnerNotification("001", "partnerA", "hello"));
		peer.asyncNotify(ChatConfig.CHAT_SERVER_ADDRESS, ChatConfig.CHAT_SERVER_PORT, new AddPartnerNotification("002", "partnerB", "yes"));
		PollNewSessionsResponse response = (PollNewSessionsResponse)peer.read(ChatConfig.CHAT_SERVER_ADDRESS, ChatConfig.CHAT_SERVER_PORT, new PollNewSessionsRequest(NodeID.DISTRIBUTED().getKey(), "Bing"));
		System.out.println(response.getNewSessionKeys().size() + " sessions are obtained!");

		in.nextLine();
		
		TerminateSignal.SIGNAL().setTerminated();

		// After the server is started, the loop check whether the flag of terminating is set. If the terminating flag is true, the process is ended. Otherwise, the process keeps running. 08/22/2014, Bing Li
		while (!TerminateSignal.SIGNAL().isTerminated())
		{
			try
			{
				// If the terminating flag is false, it is required to sleep for some time. Otherwise, it might cause the high CPU usage. 08/22/2014, Bing Li
				Thread.sleep(ServerConfig.TERMINATE_SLEEP);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
		peer.stop();

		in.close();
	}

}
