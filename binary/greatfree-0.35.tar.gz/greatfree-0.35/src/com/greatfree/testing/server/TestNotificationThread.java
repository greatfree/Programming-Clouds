package com.greatfree.testing.server;

import com.greatfree.concurrency.NotificationQueue;
import com.greatfree.testing.data.ServerConfig;
import com.greatfree.testing.message.TestNotification;

// Created: 12/10/2016, Bing Li
public class TestNotificationThread extends NotificationQueue<TestNotification> 
{
	public TestNotificationThread(int taskSize)
	{
		super(taskSize);
	}

	@Override
	public void run()
	{
		TestNotification notification;
		while (!this.isShutdown())
		{
			while (!this.isEmpty())
			{
				try
				{
					notification = this.getNotification();

					// Process the received notification here. 12/10/2016, Bing Li
					System.out.println(notification.getMessage());
					
					this.disposeMessage(notification);
				}
				catch (InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try
			{
				// Wait for a moment after all of the existing notifications are processed. 01/20/2016, Bing Li
				this.holdOn(ServerConfig.NOTIFICATION_THREAD_WAIT_TIME);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
	}

}
