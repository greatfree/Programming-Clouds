package com.greatfree.testing.searcher;

import java.util.Set;

/*
 * The constants and configurations for the searcher are saved in the class. 12/01/2014, Bing Li
 */

// Created: 11/29/2014, Bing Li
public class SearchConfig
{
	public final static Set<String> NO_LINKS = null;
}
